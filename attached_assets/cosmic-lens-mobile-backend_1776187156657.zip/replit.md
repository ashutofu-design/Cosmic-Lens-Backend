# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## Artifacts

### Cosmic Lens Mobile (`artifacts/cosmic-lens-mobile`)
Expo React Native mobile app — Vedic astrology guide (Hindi/Hinglish UI).
- **Framework**: Expo (SDK 53) + Expo Router file-based navigation
- **Key deps**: react-native-svg, expo-linear-gradient, expo-haptics, AsyncStorage
- **API base**: `https://${EXPO_PUBLIC_DOMAIN}` — never hardcode ports

**Screens (Tabs):**
- `app/(tabs)/index.tsx` — Home: EnergyChart (demo/real), ActionCard buttons → Forecast & Planet Position, Active Dasha card, SetupKundliCard
- `app/(tabs)/kundli.tsx` — Kundli: Astro Snapshot grid, Dasha Timeline MD/AD/PD cards, Timeline Strip
- `app/(tabs)/insights.tsx` — Insights: Category tabs (Career/Finance/Rishte/Swasthya), Score ring, 6-month SVG line chart, upcoming PD chips, text insight cards
- `app/(tabs)/notice.tsx` — Notice: Cosmic alerts list with colored icons, "2 new" badge, timestamps
- `app/(tabs)/ask.tsx` — Ask: Jyotish AI chatbot (calls `/api/ask`), demo conversation, starter chips
- `app/(tabs)/profile.tsx` — Profile: User settings

**New Routes:**
- `app/forecast.tsx` — 7-Day Forecast: interactive week chart, day-by-day detail (Moon Rashi, Paksha, Energy score), day navigation
- `app/planet-position.tsx` — Planet Position: expandable cards for all 9 planets (dignity, nakshatra, combustion, aspects)
- `app/onboarding.tsx` — Premium birth details form

**Key Libraries:**
- `lib/proInsightEngine.ts` — Dasha engine: `computeActiveDasha` (Home), `computeProInsight` (Insights tab), `generatePDForecast` (6-month async forecast with `/api/transits`)
- `context/UserContext.tsx` — user, birthData, kundli, todayEnergy, moonData state + AsyncStorage
- `components/EnergyChart.tsx` — SVG animated energy chart (pass `instant={true}` for demo/static)
- `components/CustomTabBar.tsx` — 6-tab custom bar with haptic feedback, red dot on Notice

### Cosmic Lens Web (`artifacts/cosmic-lens`)
React+Vite web app — full Vedic astrology dashboard. Backend: Python Flask + PySwisseph.

### API Server (`artifacts/api-server`)
Flask backend with endpoints: `/api/kundli`, `/api/transits`, `/api/ask`, `/api/auth/*`
